package org.example;

import view.AppView;

public class Main {
    public static void main(String[] args) {
        AppView.run();
    }
}