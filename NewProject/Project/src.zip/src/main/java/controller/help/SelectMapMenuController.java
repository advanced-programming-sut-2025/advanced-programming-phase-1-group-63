package controller.help;

import controller.GeneralAppController;
import model.App;
import model.Result;

public class SelectMapMenuController extends GeneralAppController {
    public Result mapSelect(App app, String number) {
        // TODO
        return null;
    }
}
