package controller.main;

import controller.GeneralAppController;
import model.App;
import model.Result;

public class StoreMenuController extends GeneralAppController {

    public Result menuExit(App app) {
        // TODO
        return null;
    }

    public Result showAllProducts(App app) {
        // TODO
        return null;
    }

    public Result showAvailableProducts(App app) {
        // TODO
        return null;
    }

    public Result purchase(App app, String productString, String countString) {
        // TODO
        return null;
    }
}
