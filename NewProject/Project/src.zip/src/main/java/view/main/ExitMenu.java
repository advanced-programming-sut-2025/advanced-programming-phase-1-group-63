package view.main;

import model.App;
import model.Result;
import view.AppMenu;

public class ExitMenu implements AppMenu {
    @Override
    public Result check(App app, String command) {
        return null;
    }
}
