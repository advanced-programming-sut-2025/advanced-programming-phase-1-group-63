package main.java.view.main;

import main.java.model.App;
import main.java.model.Result;
import main.java.view.AppMenu;

public class ExitMenu implements AppMenu {
    @Override
    public Result check(App app, String command) {
        return null;
    }
}
