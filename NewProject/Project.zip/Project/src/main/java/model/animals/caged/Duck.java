package model.animals.caged;

import model.animals.caged.CoopAnimal;

public class Duck extends CoopAnimal {
    public Duck(String name) { super(name); }
}