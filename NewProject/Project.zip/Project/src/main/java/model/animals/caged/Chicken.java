package model.animals.caged;

import model.animals.caged.CoopAnimal;

public class Chicken extends CoopAnimal {
    public Chicken(String name) { super(name); }
}