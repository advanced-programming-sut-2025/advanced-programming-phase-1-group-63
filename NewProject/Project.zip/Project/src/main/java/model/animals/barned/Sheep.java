package model.animals.barned;

import model.animals.BarnAnimal;

public class Sheep extends BarnAnimal {
    public Sheep(String name) { super(name); }
}