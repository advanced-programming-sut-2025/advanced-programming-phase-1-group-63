package model;

public class Tile {
}
