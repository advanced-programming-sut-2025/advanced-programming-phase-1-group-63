package model;

public class Weather {
}
