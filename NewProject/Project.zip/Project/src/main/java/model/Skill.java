package model;

public class Skill {
}
