package model;

public class Map {
    int width;
    int height;

}
