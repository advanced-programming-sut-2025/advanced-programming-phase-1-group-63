package model.map;

public interface Item {
}
