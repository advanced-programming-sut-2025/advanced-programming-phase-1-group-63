package model.enums;

public enum TradeType {
    OFFER,
    REQUEST
}
