package model.enums;

public enum Gender {
    Man,
    Woman;
}
