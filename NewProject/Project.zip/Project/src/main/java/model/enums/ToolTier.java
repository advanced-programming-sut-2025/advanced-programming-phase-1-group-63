// File: model/enums/ToolTier.java
package model.enums;

public enum ToolTier {
    BASIC,
    COPPER,
    IRON,
    GOLD,
    IRIDIUM;
}