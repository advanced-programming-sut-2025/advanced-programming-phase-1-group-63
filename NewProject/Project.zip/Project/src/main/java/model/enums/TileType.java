package model.map;


public enum TileType {
    EMPTY,
    HOUSE,
    TREE,
    LAKE,
    FARM,
    GRASS;
}

