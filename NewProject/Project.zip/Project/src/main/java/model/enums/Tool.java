package model.enums;

public enum Tool {

    ;

    private Material material;

    Tool(Material material) {
        this.material = material;
    }
}
