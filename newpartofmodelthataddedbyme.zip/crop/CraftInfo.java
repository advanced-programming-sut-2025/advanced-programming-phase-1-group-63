package model.crop;

// the example that we use this crop for this !
public class CraftInfo {
   /* public static void main(String[] args) {
        if (args.length != 2 || !"-n".equals(args[0])) {
            System.err.println("Usage: craftinfo -n <crop_name>");
            System.exit(1);
        }
        String name = args[1];
        CropRegistry.get(name).ifPresentOrElse(crop -> crop.printInfo(),
                () -> {
                    System.err.printf("Error: No crop found with name '%s'\n", name);
                    System.exit(2);
                }
        );
    }*/
}