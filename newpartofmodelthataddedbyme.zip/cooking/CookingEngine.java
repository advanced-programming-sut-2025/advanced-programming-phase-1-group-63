package model.cooking;

import model.Player;

public class CookingEngine {
    private final Player player;

    public CookingEngine(Player player) { this.player = player; }

    public void handle(String[] args) {
        // parse commands starting with "cooking"
    }
}