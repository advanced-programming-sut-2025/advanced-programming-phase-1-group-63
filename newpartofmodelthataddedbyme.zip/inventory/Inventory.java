package model.inventory;

import model.animals.store.Product;
import model.animals.store.*;

public class Inventory {
    Inventory inventory;
    Product product;

    public Inventory() {

    }
}
