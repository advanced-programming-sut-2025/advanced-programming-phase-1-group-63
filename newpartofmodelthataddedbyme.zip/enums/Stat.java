package model.enums;
public enum Stat {
    MAX_ENERGY,
    FARMING,
    FORAGING,
    MINING,
    FISHING;
}