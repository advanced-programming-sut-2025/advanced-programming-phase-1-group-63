package model.enums;

public enum Item {
}
