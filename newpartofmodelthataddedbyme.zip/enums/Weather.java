package model.enums;

// weather condition for fishing
public enum Weather {
    SUNNY,
    RAIN,
    STORM,
    OTHER;
}

