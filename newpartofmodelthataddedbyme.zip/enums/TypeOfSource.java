package model.enums;

public enum TypeOfSource {
    STARTER,
    STARDROP_SALOON,
    LEAH_REWARD,
    FORAGING_L2,
    FORAGING_L3,
    FARMING_L1,
    FISHING_L2,
    FISHING_L3,
    MINING_L1;
}