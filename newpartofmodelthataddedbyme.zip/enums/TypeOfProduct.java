package model.enums;

public enum TypeOfProduct {
    BASIC,
    SILVER,
    GOLD,
    IRIDIUM;
 /*
  *if(!TypeOfProduct) return "invalid TypeforProduct";
  *return TypeOfProduct;
  */
    // this file maybe helpful for the base of animals product like cow,chicken;
}

