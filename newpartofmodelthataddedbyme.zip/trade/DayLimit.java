package model.trade;

public enum DayLimit {
    unlimited,
    limited;
}
