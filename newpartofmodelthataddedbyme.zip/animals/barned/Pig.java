package model.animals.barned;

import model.animals.BarnAnimal;

public class Pig extends BarnAnimal {
    public Pig(String name) { super(name); }
}