package model.animals.barned;

import model.animals.BarnAnimal;

public class Cow extends BarnAnimal {
    public Cow(String name) { super(name); }
}
