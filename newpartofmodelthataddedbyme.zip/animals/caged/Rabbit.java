package model.animals.caged;

import model.animals.caged.CoopAnimal;

public class Rabbit extends CoopAnimal {
    public Rabbit(String name) { super(name); }
}