package model;

import model.enums.SkillType;

/**
 * Represents a player’s skill in a given domain, tracking experience and level.
 */
public class Skill {
    public static final int MAX_LEVEL = 10;
    private int level;
    private int experience;
    private static final int[] XP_THRESHOLDS = {
            0,    // level 0
            100,  // to reach level 1
            250,  // to reach level 2
            450,  // ...
            700,
            1000,
            1350,
            1750,
            2200,
            2700,
            3250   // to reach MAX_LEVEL
    };

    public Skill(int startingLevel, int startingXp) {
        this.level = Math.min(startingLevel, MAX_LEVEL);
        this.experience = Math.max(startingXp, XP_THRESHOLDS[this.level]);
    }

    /**
     * return current level!!!
     */
    public int getLevel() {
        return level;
    }

    /**
     * return ex of know !!!
     */
    public int getExperience() {
        return experience - XP_THRESHOLDS[level];
    }


    public int getXpToNextLevel() {
        if (level >= MAX_LEVEL) return 0;
        return XP_THRESHOLDS[level + 1] - XP_THRESHOLDS[level];
    }


    public double getProgressRatio() {
        if (level >= MAX_LEVEL) return 1.0;
        return (double) getExperience() / getXpToNextLevel();
    }


    public void addExperience(int xpGain) {
        if (level >= MAX_LEVEL) return;
        experience += xpGain;

        while (level < MAX_LEVEL && experience >= XP_THRESHOLDS[level + 1]) {
            level++;
        }
        if (level == MAX_LEVEL) {
            experience = XP_THRESHOLDS[MAX_LEVEL];
        }
    }

    @Override
    public String toString() {
        if (level >= MAX_LEVEL) {
            return String.format("Level %d (MAX)", level);
        }
        return String.format("Level %d (%.0f%%)",
                level,
                getProgressRatio() * 100
        );
    }
}
