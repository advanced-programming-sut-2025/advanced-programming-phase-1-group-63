package model.animals.caged;

public class Dinosaur extends CoopAnimal {
    public Dinosaur(String name) { super(name); }
}