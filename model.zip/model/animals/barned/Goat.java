package model.animals.barned;

import model.animals.BarnAnimal;

public class Goat extends BarnAnimal {
    public Goat(String name) { super(name); }
}
