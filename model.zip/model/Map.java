// model/tools/GameMap.java
package model;

import model.Position;
import model.Tile;
import model.enums.Direction;

import java.util.Arrays;

/**
 * Represents the game world as a 2D grid of Tiles.
 */
public class Map {
    private static int width ;
    private static int height;
    private static Tile[][] tiles = null;

    /**
     * Create a GameMap of given size, initialized with the provided tile grid.
     * @param tiles 2D array of Tiles, sized [height][width]
     **/
    public Map(Tile[][] tiles) {
        height = tiles.length;
        width = tiles.length > 0 ? tiles[0].length : 0;
        // deep copy to prevent external modifications
        Map.tiles = new Tile[height][width];
        for (int y = 0; y < height; y++) {
            if (tiles[y].length != width) {
                throw new IllegalArgumentException("All rows must have same length");
            }
            Map.tiles[y] = Arrays.copyOf(tiles[y], width);
        }
    }

    public Map(int i, int i1) {
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    /**
     * Returns the tile at the specified position.
     * @param pos the position to query
     * @return the Tile at pos
     * @throws IndexOutOfBoundsException if pos is outside the map
     */
    public static Tile getTileAt(Position pos) {
        if (pos.getX() < 0 || pos.getX() >= width
                || pos.getY() < 0 || pos.getY() >= height) {
            throw new IndexOutOfBoundsException("Position out of map bounds: " + pos);
        }
        return tiles[pos.getY()][pos.getX()];
    }

    /**
     * Returns the adjacent tile in the given direction from the given position.
     * Supports all eight compass directions.
     *
     * @param pos current position
     * @param dir direction to move
     * @return the adjacent Tile
     * @throws IndexOutOfBoundsException if the adjacent position is off the map
     */
    public Tile getAdjacent(Position pos, Direction dir) {
        Position target;
        switch (dir) {
            case NORTH:
                target = pos.offset(0, -1);
                break;
            case SOUTH:
                target = pos.offset(0, 1);
                break;
            case EAST:
                target = pos.offset(1, 0);
                break;
            case WEST:
                target = pos.offset(-1, 0);
                break;
            case NORTHEAST:
                target = pos.offset(1, -1);
                break;
            case NORTHWEST:
                target = pos.offset(-1, -1);
                break;
            case SOUTHEAST:
                target = pos.offset(1, 1);
                break;
            case SOUTHWEST:
                target = pos.offset(-1, 1);
                break;
            default:
                throw new IllegalArgumentException("Unknown direction: " + dir);
        }
        return getTileAt(target);
    }
}
