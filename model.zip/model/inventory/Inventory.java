package model.inventory;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * Manages quantities of InventoryItem instances.
 *
 * @param <T> Type of item stored in this inventory.
 */
public class Inventory<T extends InventoryItem> {
    private final Map<T, Integer> items = new HashMap<>();

    /**
     * Adds a quantity of an item to the inventory.
     *
     * @param item     The item to add.
     * @param quantity Number of units to add (must be positive).
     */
    public void add(T item, int quantity) {
        if (quantity <= 0) {
            throw new IllegalArgumentException("Quantity must be positive");
        }
        items.merge(item, quantity, Integer::sum);
    }

    /**
     * Removes a quantity of an item from the inventory.
     *
     * @param item     The item to remove.
     * @param quantity Number of units to remove (must be positive).
     * @return
     * @throws IllegalStateException if not enough quantity is present.
     */
    public boolean remove(T item, int quantity) {
        if (quantity <= 0) {
            throw new IllegalArgumentException("Quantity must be positive");
        }
        int current = items.getOrDefault(item, 0);
        if (current < quantity) {
            throw new IllegalStateException(
                    "Not enough " + item.getName() + " to remove. Requested=" + quantity + ", Available=" + current
            );
        }
        if (current == quantity) {
            items.remove(item);
        } else {
            items.put(item, current - quantity);
        }
        return false;
    }

    /**
     * Checks if the inventory has at least the given quantity of an item.
     */
    public boolean has(T item, int quantity) {
        return items.getOrDefault(item, 0) >= quantity;
    }

    /**
     * Retrieves current quantity of an item (0 if absent).
     */
    public int getQuantity(T item) {
        return items.getOrDefault(item, 0);
    }

    /**
     * Returns an unmodifiable view of all items and their quantities.
     */
    public Map<T, Integer> getContents() {
        return Collections.unmodifiableMap(items);
    }

    /**
     * Lists all distinct items in the inventory.
     */
    public Set<T> listItems() {
        return Collections.unmodifiableSet(items.keySet());
    }

    /**
     * Clears the inventory completely.
     */
    public void clear() {
        items.clear();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("Inventory Contents:\n");
        items.forEach((item, qty) -> sb.append(" - ")
                .append(item.getName())
                .append(" x")
                .append(qty)
                .append("\n"));
        return sb.toString();
    }

}
