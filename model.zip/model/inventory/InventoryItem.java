package model.inventory;

public interface InventoryItem {


    String getName();
}
