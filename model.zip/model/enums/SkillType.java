package model.enums;

public enum SkillType {
    FARMING,
    MINING,
    FORAGING,
    FISHING;
}