package model.enums;

/**
 * Edibility status of products.
 */
public enum Edibility {EDIBLE, INEDIBLE}
