package model.enums;

public interface Material {
    Material upgrade();
}
