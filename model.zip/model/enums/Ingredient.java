package model.enums;

import model.inventory.InventoryItem;

public enum Ingredient implements InventoryItem {
    EGG, WHEAT, LEEK, COFFEE,
    SUGAR, POTATO, CORN, RICE, DANDELION,
    OIL, SALMON, ANY_FISH, TOMATO,
    MILK, CHEESE, FISHING_FISH, BEET,
    BREAD, CARROT, EGGPLANT, FIBER,
    FLOUNDER, MIDNIGHT_CARP, RED_CABBAGE,
    BLUEBERRY, APRICOT, MELON, PARSNIP, WHEAT_FLOUR,
    RADISH, KALE, OMELETHASH_BROWNS, SARDINE,
    OMELET,AMARANTH, PUMPKIN, HASH_BROWNS;

    @Override
    public String getName() {
        return "";
    }
}
