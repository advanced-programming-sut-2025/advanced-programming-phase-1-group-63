package model.cooking;

public class Craft {
}
