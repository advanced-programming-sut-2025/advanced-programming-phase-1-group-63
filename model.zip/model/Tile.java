package model;

import model.enums.TileType;
import model.enums.ToolTier;
import model.tools.FishingRod;
import model.tools.WateringCan;

import java.util.Random;

/**
 * Represents a tile on the game map that can be interacted with via tools.
 */
public class Tile {
    private final TileType type;
    private int durability;

    public Tile(TileType type, int durability) {
        this.type = type;
        this.durability = durability;/* !!!دوام یا مقاومت هر کاشی!!! */
    }

    /**
     * @return the type of this tile
     */
    public TileType getType() {
        return type;
    }

    /**
     * @return if this tile can be chopped (e.g. a tree)
     */
    public boolean isChoppable() {
        return type.isChoppable();
    }

    /**
     * @return if this tile can be fished (e.g. water)
     */
    public boolean isFishable() {
        return type.isFishable();
    }

    /**
     * @return if this tile can be hoed (e.g. dirt)
     */
    public boolean isTillable() {
        return type.isTillable();
    }

    /**
     * @return if this tile has a mature crop to harvest
     */
    public boolean isHarvestable() {
        return type.isHarvestable();
    }

    /**
     * @return if this tile has an animal that can be sheared
     */
    public boolean isShearable() {
        return type.isShearable();
    }

    /**
     * @return if this tile currently holds a crop (for watering)
     */
    public boolean isCrop() {
        return type.isCrop();
    }

    /**
     * @return if this tile contains a water source (for filling can)
     */
    public boolean hasWaterSource() {
        return type.isWaterSource();
    }

    /**
     * Chop this tile with the given tool tier, reducing its durability.
     *
     * @param tier the tier of the axe being used
     * @throws IllegalStateException if the tile is not choppable
     */
    public void chop(ToolTier tier) {
        if (!isChoppable()) {
            throw new IllegalStateException("Cannot chop tile of type " + type);
        }
        int damage = tier.getDamage();
        durability -= damage;
        if (durability <= 0) {
            // TODO: remove tile and spawn wood/log drops
        }
    }

    /**
     * Fish on this tile with the given rod.
     *
     * @param rod the fishing rod being used
     * @throws IllegalStateException if the tile is not fishable or no catch
     */
    public void fish(FishingRod rod) {
        if (!isFishable()) {
            throw new IllegalStateException("Cannot fish on tile type " + type);
        }
        int chance = rod.getEfficiency();
        boolean success = new Random().nextInt(100) < chance;
        if (!success) {
            throw new IllegalStateException("No fish caught");
        }
        // TODO: spawn fish item or add to player inventory externally
    }

    /**
     * Hoe this tile, turning it into tillable soil.
     *
     * @throws IllegalStateException if the tile is not tillable
     */
    public void hoe() {
        if (!isTillable()) {
            throw new IllegalStateException("Cannot hoe tile of type " + type);
        }
        // TODO: change tile state to hoed soil
    }

    /**
     * Harvest the crop on this tile.
     *
     * @throws IllegalStateException if the tile has nothing to harvest
     */
    public void harvest() {
        if (!isHarvestable()) {
            throw new IllegalStateException("Cannot harvest tile of type " + type);
        }
        // TODO: remove crop and spawn produce/item
    }

    /**
     * Shear the animal on this tile.
     *
     * @throws IllegalStateException if there's no shearable animal here
     */
    public void shearAnimal() {
        if (!isShearable()) {
            throw new IllegalStateException("Cannot shear on tile type " + type);
        }
        // TODO: spawn wool or other animal product
    }

    /**
     * Water the crop on this tile.
     *
     * @throws IllegalStateException if there's no crop to water
     */
    public void water() {
        if (!isCrop()) {
            throw new IllegalStateException("Cannot water tile type " + type);
        }
        // TODO: mark crop as watered for the day
    }

    /**
     * Fill the watering can from this water source.
     *
     * @param can the watering can being filled
     * @throws IllegalStateException if this tile has no water source
     */
    public void fillCan(WateringCan can) {
        if (!hasWaterSource()) {
            throw new IllegalStateException("Cannot fill can here, tile type " + type);
        }
        // TODO: set can to full state
    }
}
