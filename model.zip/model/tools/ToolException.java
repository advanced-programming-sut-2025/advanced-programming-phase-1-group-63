package model.tools;

public class ToolException extends RuntimeException {
    public ToolException(String message) {
        super(message);
    }
}
