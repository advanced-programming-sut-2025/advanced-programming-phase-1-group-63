package model.enums;

import model.Item;
import java.util.Map;
import java.util.Collections;

public enum Craft {
    CHERRY_BOMB(
        Map.of(Resource.COPPER_ORE, 4,
               Resource.COAL, 1)
    ),
    BOMB(
        Map.of(Resource.IRON_ORE, 4,
               Resource.COAL, 1)
    ),
    MEGA_BOMB(
        Map.of(Resource.GOLD_ORE, 4,
               Resource.COAL, 1)
    ),
    SPRINKLER(
        Map.of(Resource.COPPER_BAR, 1,
               Resource.IRON_BAR,  1)
    ),
    QUALITY_SPRINKLER(
        Map.of(Resource.IRON_BAR, 1,
               Resource.GOLD_BAR, 1)
    ),
    IRIDIUM_SPRINKLER(
        Map.of(Resource.GOLD_BAR,    1,
               Resource.IRIDIUM_BAR, 1)
    ),
    CHARCOAL_KILN(
        Map.of(Resource.WOOD,      20,
               Resource.COPPER_BAR, 2)
    ),
    FURNACE(
        Map.of(Resource.COPPER_ORE, 20,
               Resource.STONE,      25)
    ),
    SCARECROW(
        Map.of(Resource.WOOD,   50,
               Resource.COAL,   1,
               Resource.FIBER,  20)
    ),
    DELUXE_SCARECROW(
        Map.of(Resource.WOOD,        50,
               Resource.COAL,        1,
               Resource.FIBER,       20,
               Resource.IRIDIUM_ORE, 1)
    ),
    BEE_HOUSE(
        Map.of(Resource.WOOD,     40,
               Resource.COAL,     8,
               Resource.IRON_BAR, 1)
    ),
    CHEESE_PRESS(
        Map.of(Resource.WOOD,      45,
               Resource.STONE,     45,
               Resource.COPPER_BAR,1)
    ),
    KEG(
        Map.of(Resource.WOOD,      30,
               Resource.COPPER_BAR,1,
               Resource.IRON_BAR, 1)
    ),
    LOOM(
        Map.of(Resource.WOOD,  60,
               Resource.FIBER, 30)
    ),
    MAYONNAISE_MACHINE(
        Map.of(Resource.WOOD,      15,
               Resource.STONE,     15,
               Resource.COPPER_BAR,1)
    ),
    OIL_MAKER(
        Map.of(Resource.WOOD,     100,
               Resource.GOLD_BAR, 1,
               Resource.IRON_BAR, 1)
    ),
    PRESERVES_JAR(
        Map.of(Resource.WOOD,      50,
               Resource.STONE,     40,
               Resource.COAL,      8)
    ),
    DEHYDRATOR(
        Map.of(Resource.WOOD,       30,
               Resource.STONE,      20,
               Resource.FIBER,      30)
    ),
    GRASS_STARTER(
        Map.of(Resource.WOOD,  1,
               Resource.FIBER, 1)
    ),
    FISH_SMOKER(
        Map.of(Resource.WOOD,      50,
               Resource.IRON_BAR, 3,
               Resource.COAL,     10)
    ),
    MYSTIC_TREE_SEED(
        Map.of(Resource.ACORN,          5,
               Resource.MAPLE_SEED,     5,
               Resource.PINE_CONE,      5,
               Resource.MAHOGANY_SEED,  5)
    );

    private final Map<Item,Integer> ingredients;
    private final int energyCost;

    Craft(Map<Item,Integer> ingredients) {
        this.ingredients = Collections.unmodifiableMap(ingredients);
        this.energyCost  = 2;
    }

    //مواد لازم
    public Map<Item,Integer> getIngredients() {
        return ingredients;
    }

    //مقدار انرژی مصرفی 
    public int getEnergyCost() {
        return energyCost;
    }
}