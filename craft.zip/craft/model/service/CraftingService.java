package service;

import model.Player;
import model.Item;
import model.enums.Craft;
import model.enums.Direction;

public class CraftingService {

    private final PlayerService    playerService;
    private final InventoryService inventoryService;
    private final MapService       mapService;
    private final MessageService   messageService;

    public CraftingService(PlayerService ps,
                           InventoryService is,
                           MapService ms,
                           MessageService msgs) {
        this.playerService    = ps;
        this.inventoryService = is;
        this.mapService       = ms;
        this.messageService   = msgs;
    }

    public void showRecipes(String username) {
        Player p = playerService.getPlayer(username);
        requireAtHome(p);

        StringBuilder sb = new StringBuilder("=== Crafting Recipes ===\n");
        for (Craft c : Craft.values()) {
            sb.append(c.name())
              .append(p.knowsCraft(c) ? " (learned)\n" : " (locked)\n");
        }
        messageService.sendSystemMessage(username, sb.toString());
    }

    //ساختن ایتم
    public void craft(String username, String craftName) {
        Player p = playerService.getPlayer(username);
        requireAtHome(p);

        Craft craft;
        try {
            craft = Craft.valueOf(craftName
                      .toUpperCase()
                      .replace(' ', '_'));
        } catch (IllegalArgumentException e) {
            throw new IllegalStateException(
                    "No such crafting recipe: " + craftName);
        }

        if (!p.knowsCraft(craft)) {
            throw new IllegalStateException(
                    "You have not learned: " + craft.name());
        }
        if (p.getEnergy() < craft.getEnergyCost()) {
            throw new IllegalStateException(
                    "Not enough energy to craft: " + craft.name());
        }
        if (inventoryService.isFull(p)) {
            throw new IllegalStateException("Your inventory is full.");
        }

        // چک مواد اولیه
        for (Item mat : craft.getIngredients().keySet()) {
            int qty = craft.getIngredients().get(mat);
            if (!inventoryService.hasItem(p, mat, qty)) {
                throw new IllegalStateException(
                        "Missing material: " + mat);
            }
        }

        // مصرف مواد و انرژی
        for (Item mat : craft.getIngredients().keySet()) {
            inventoryService.removeItem(p, mat,
                                        craft.getIngredients().get(mat));
        }
        p.addEnergy(-craft.getEnergyCost());
        inventoryService.addItem(p, craft, 1);

        messageService.sendSystemMessage(username,
            "You have crafted 1 × " + craft.name() +
            " (–" + craft.getEnergyCost() + " energy).");
    }

    //ایتم بزاره رو زمین
    public void placeItem(String username,
                          String itemName,
                          String dir) {
        Player p = playerService.getPlayer(username);
        requireAtHome(p);

        Direction direction = Direction.fromString(dir);
        Item item = inventoryService.findItemByName(p, itemName);
        if (item == null) {
            throw new IllegalStateException(
                    "You do not have: " + itemName);
        }
        inventoryService.removeItem(p, item, 1);
        mapService.placeItemAt(p.getPosition(),
                               direction, item);

        messageService.sendSystemMessage(username,
            "You placed " + itemName + " to the " + direction + ".");
    }

    private void requireAtHome(Player p) {
        if (!playerService.isAtHome(p)) {
            throw new IllegalStateException(
                    "You must be at home to use crafting.");
        }
    }
}
