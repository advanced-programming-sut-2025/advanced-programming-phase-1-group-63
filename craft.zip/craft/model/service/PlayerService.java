package service;

import model.Player;
import model.Position;
import model.Map;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class PlayerService {
    private final Map<String, Player> players = new ConcurrentHashMap<>();

    public void addPlayer(Player p) {
        players.put(p.getUsername(), p);
    }

    //کلا این کلاس رو فقط برای این تیکه چیز میز بر میداره گذاشتم
    public Player getPlayer(String username) {
        Player p = players.get(username);
        if (p == null) {
            throw new IllegalArgumentException("No such player: " + username);
        }
        return p;
    }

    public boolean isAtHome(Player p) {
        Position pos = p.getPosition();
        Map    map = p.getMap();
        if (pos == null || map == null) {
            return false;
        }
        return pos.equals(map.getHomePosition());
    }
}
