package service;

import model.Player;
import model.Item;

import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.util.ArrayList;


public class InventoryService {
    private static final int MAX_SLOTS = 36;
    private final Map<Player, Map<Item,Integer>> inventories = new HashMap<>();

    private Map<Item,Integer> invOf(Player p) {
        return inventories.computeIfAbsent(p, k -> new HashMap<>());
    }

    //چک کردن داشتن حداقل
    public boolean hasItem(Player p, Item item, int qty) {
        return invOf(p).getOrDefault(item, 0) >= qty;
    }

    
    public void addItem(Player p, Item item, int qty) {
        Map<Item,Integer> inv = invOf(p);
        inv.put(item, inv.getOrDefault(item, 0) + qty);
    }

    // کم کردن qty عدد از item (در صورت کمبود Exception)
    public void removeItem(Player p, Item item, int qty) {
        Map<Item,Integer> inv = invOf(p);
        int cur = inv.getOrDefault(item, 0);
        if (cur < qty) {
            throw new IllegalStateException("Not enough items: " + item);
        }
        if (cur == qty) {
            inv.remove(item);
        } else {
            inv.put(item, cur - qty);
        }
    }

    //اینونتوری پره؟
    public boolean isFull(Player p) {
        return invOf(p).size() >= MAX_SLOTS;
    }

    //پیدا کردن بر اساس نام
    public Item findItemByName(Player p, String itemName) {
        for (Item it : invOf(p).keySet()) {
            if (it.name().equalsIgnoreCase(itemName)) {
                return it;
            }
        }
        return null;
    }

    //لیست ساده نمایش موجودی
    public List<String> listInventory(Player p) {
        List<String> out = new ArrayList<>();
        invOf(p).forEach((it, cnt) ->
            out.add(it.name() + " x " + cnt)
        );
        return out;
    }
}

//این احتمالا خیلی کار داشته باشه صرفا فقط واسه بخش کرفتینگ احساس کردم یه چیزایی لازم داره