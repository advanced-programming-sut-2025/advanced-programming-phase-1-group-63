package model;

import model.enums.Craft;
import java.util.Set;
import java.util.HashSet;

public class Player extends User {

    private int energy = 200;

    private final Set<Craft> knownCrafts = new HashSet<>();

    public Player(User base) {
        super(base.getUsername(),
              base.getPassword(),
              base.getNickname(),
              base.getEmail(),
              base.getGender());
    }

    //چک کردن اینکه مهارتو بلده یا نه
    public boolean knowsCraft(Craft craft) {
        return knownCrafts.contains(craft);
    }

    //مهارت جدید
    public void learnCraft(Craft craft) {
        knownCrafts.add(craft);
    }

    //هرچی بلده
    public Set<Craft> getKnownCrafts() {
        return Set.copyOf(knownCrafts);
    }

    //انرژی فعلی
    @Override
    public int getEnergy() {
        return energy;
    }

    //تغییر انرژی
    public void addEnergy(int delta) {
        this.energy += delta;
    }

    // این کلاس صرفا برای پیشتبانی crafting زدمش
    //بعدا باید احتمالا با بقیه چیزا یکیش کنیم
}
