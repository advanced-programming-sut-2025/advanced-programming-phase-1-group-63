package model;

import java.util.ArrayList;

public class Player extends User {
    private Position position;
    private Map map = null;
    private int energy = 200;
    // بقیه فیلدامون...
    private int daysPlayed = 0;  

    // TODO: یه اینونتوری کامل باید بنویسیم
    private Inventory inventory = new Inventory();


    public Player(User user) {
        super(user.getUsername(), user.getPassword(),
              user.getNickname(), user.getEmail(), user.getGender());
    }

    public Position getPosition() {
        return position;
    }
    public void setPosition(Position position) {
        this.position = position;
    }

    // شمارش روزها
    public int getDaysPlayed() {
        return daysPlayed;
    }
    public void nextDay() {
        daysPlayed++;
    }

    public boolean hasItem(String itemName) {
        return inventory.has(itemName);
    }
    public void removeItem(String itemName) {
        inventory.remove(itemName);
    }
    public void addItem(String itemName) {
        inventory.add(itemName);
    }

    // چیزای قبلی....
}
