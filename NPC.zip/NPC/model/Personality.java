package model;

public enum Personality {
    CHEERFUL,
    SHY,
    ROMANTIC,
    PRACTICAL,
    ADVENTUROUS,
    GRUMPY,
    KIND,
    ARTISTIC,
    LOGICAL,
    DREAMY
}
