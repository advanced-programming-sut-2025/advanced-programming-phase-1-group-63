package model;

public enum TimeOfDay {
    MORNING,
    AFTERNOON,
    EVENING
}
