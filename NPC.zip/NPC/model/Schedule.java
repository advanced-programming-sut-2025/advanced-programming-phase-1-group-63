package model;

import java.util.Map;

public class Schedule {
    // سیو مکان دوستان ان پی سی
    private final Map<TimeOfDay, Location> routine;

    public Schedule(Map<TimeOfDay, Location> routine) {
        this.routine = routine;
    }

    public Location whereAt(TimeOfDay t) {
        return routine.get(t);
    }
}
