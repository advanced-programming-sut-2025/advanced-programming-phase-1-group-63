package model;

import main.java.model.enums.NPC;
import java.util.List;
import java.util.Random;

public class GiftSystem {

    public static void giveGift(Player p, NPC npc, String item) {
        int day = p.getDaysPlayed();
        Friendship fr = npc.getFriendship();

        // پول داری یارو؟
        if (!p.hasItem(item)) {
            System.out.println("You don't have " + item + ".");
            return;
        }
        // جایزت
        if (fr.getLastGiftDay() == day) {
            System.out.println("You already gave a gift to " + npc.getName() + " today.");
            return;
        }
        //برو بمیر از اینونتوری
        p.removeItem(item);

        int gain;
        if (npc.getFavorites().contains(item)) {
            gain = 200;
            System.out.println("They loved it! +200 friendship.");
        } else {
            gain = 50;
            System.out.println("Gift received. +50 friendship.");
        }
        fr.addPoints(gain);
        fr.setLastGiftDay(day);
    }

    public static void sendDailyNPCGifts(Player p) {
        Random rnd = new Random();
        int day = p.getDaysPlayed();

        for (NPC npc : NPC.values()) {
            Friendship fr = npc.getFriendship();
            if (fr.getLastGiftDay() == day) continue; // فقط یه بار میشه ها تو روز

            if (rnd.nextDouble() < 0.5) {
                List<String> favs = npc.getFavorites();
                String gift = favs.get(rnd.nextInt(favs.size()));
                p.addItem(gift);
                fr.setLastGiftDay(day);
                System.out.printf("%s sent you a gift: %s\n", npc.getName(), gift);
            }
        }
    }
}
