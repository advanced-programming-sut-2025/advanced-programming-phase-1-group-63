package model;

public class Location {
    private final String name;
    private final Position position;  // اینو من فرض کردما

    public Location(String name, Position position) {
        this.name = name;
        this.position = position;
    }

    public String getName() {
        return name;
    }

    public Position getPosition() {
        return position;
    }
}
