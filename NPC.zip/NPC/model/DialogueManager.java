package model;

import main.java.model.enums.NPC;
import java.time.LocalDate;
import java.util.*;

public class DialogueManager {
    private static final Map<NPC, Map<TimeOfDay, List<String>>> dialogues = new HashMap<>();

    static {
        // LEAH
        dialogues.put(NPC.LEAH, Map.of(
            TimeOfDay.MORNING, List.of(
                "Good morning! The forest looks magical today, isn't it?",
                "Hi there! Isn't the dew on the leaves beautiful?"
            ),
            TimeOfDay.AFTERNOON, List.of(
                "I'm working on a new sculpture—care to take a look?",
                "It's peaceful here in my cabin. Come say hi anytime!"
            ),
            TimeOfDay.EVENING, List.of(
                "The sunset tonight is inspiring me to paint.",
                "Evening! Would you like some fresh paintings?"
            )
        ));
        // ROBIN
        dialogues.put(NPC.ROBIN, Map.of(
            TimeOfDay.MORNING, List.of(
                "Morning! I've got a new plank design I want to try.",
                "Hey! Need any help with building?"
            ),
            TimeOfDay.AFTERNOON, List.of(
                "Afternoon! The shop is open if you need tools.",
                "Working on a new upgrade—exciting stuff!"
            ),
            TimeOfDay.EVENING, List.of(
                "Evening! Want to grab a drink at the saloon?",
                "Packing up for the day—see you tomorrow!"
            )
        ));
        // SEBASTIAN
        dialogues.put(NPC.SEBASTIAN, Map.of(
            TimeOfDay.MORNING, List.of(
                "Mornin'. The code compiled perfectly last night.",
                "Hi. Want to talk about astronomy?"
            ),
            TimeOfDay.AFTERNOON, List.of(
                "I’m debugging my latest program—wish me luck.",
                "Ever seen the northern lights? They're amazing."
            ),
            TimeOfDay.EVENING, List.of(
                "Night’s my favorite time to code.",
                "Care for a walk by the river under the stars?"
            )
        ));
        // ABIGAIL
        dialogues.put(NPC.ABIGAIL, Map.of(
            TimeOfDay.MORNING, List.of(
                "Hey! The mine’s calling my name.",
                "Morning! Ready for an adventure?"
            ),
            TimeOfDay.AFTERNOON, List.of(
                "I found a weird artifact today!",
                "This town’s too quiet—let’s find something to do."
            ),
            TimeOfDay.EVENING, List.of(
                "Evening! Wanna play some video games?",
                "Got any spooky stories?"
            )
        ));
        // HARVEY
        dialogues.put(NPC.HARVEY, Map.of(
            TimeOfDay.MORNING, List.of(
                "Good morning. The clinic’s ready for patients.",
                "Hi there, come by if you need a check-up."
            ),
            TimeOfDay.AFTERNOON, List.of(
                "Afternoon! Remember to stay hydrated.",
                "I’m researching a new remedy."
            ),
            TimeOfDay.EVENING, List.of(
                "Evening. The stars are clear tonight.",
                "Take care heading home."
            )
        ));
    }

    //یه سری کارای اسگولی واسه خوشگلی

    public static void meet(Player player, NPC npc, TimeOfDay time) {
        Position pPos = player.getPosition();
        Position nPos = npc.getSchedule().whereAt(time).getPosition();

        if (Math.abs(pPos.getX() - nPos.getX()) <= 1 &&
            Math.abs(pPos.getY() - nPos.getY()) <= 1) {

            Friendship fr = npc.getFriendship();
            LocalDate today = LocalDate.now();

            // اولین ملاقات امروز؟
            if (fr.getLastMetDate() == null || !fr.getLastMetDate().equals(today)) {
                fr.addPoints(20);
                fr.setLastMetDate(today);
                System.out.printf("[%s] First meeting today: +20 friendship\n", npc.getName());
            }

            // یدونه تصادفی هم بزاریم این وسط
            List<String> lines = dialogues.get(npc).get(time);
            String line = lines.get(new Random().nextInt(lines.size()));
            System.out.printf("%s says: \"%s\"\n", npc.getName(), line);

        } else {
            System.out.printf("[%s] is too far away to talk.\n", npc.getName());
        }
    }
}
