package model;

import java.time.LocalDateTime;

public class Friendship {
    private final String userA;
    private final String userB;
    private int xp;
    private int level;
    private LocalDateTime lastInteraction;

    // برای ازدواج
    private boolean married = false;
    private String spouseUsername = null;

    public Friendship(String userA, String userB) {
        this.userA = userA;
        this.userB = userB;
        this.xp = 0;
        this.level = 0;
        this.lastInteraction = LocalDateTime.now();
    }
-
    public String getUserA() {
        return userA;
    }
    public String getUserB() {
        return userB;
    }
    public int getXp() {
        return xp;
    }
    public void setXp(int xp) {
        this.xp = xp;
    }
    public int getLevel() {
        return level;
    }
    public void setLevel(int level) {
        this.level = level;
    }
    public LocalDateTime getLastInteraction() {
        return lastInteraction;
    }
    public void setLastInteraction(LocalDateTime lastInteraction) {
        this.lastInteraction = lastInteraction;
    }

    //ازدواج 
    public boolean isMarried() {
        return married;
    }
    public String getSpouseUsername() {
        return spouseUsername;
    }

    public void marry(String spouseUsername) {
        this.level = 4;
        this.married = true;
        this.spouseUsername = spouseUsername;
    }

    public void divorce() {
        this.level = 0;
        this.married = false;
        this.spouseUsername = null;
    }

    // TODO: شاید واسه ایکس پی نیاز شه
}
