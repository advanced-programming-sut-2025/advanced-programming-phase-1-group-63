package main.java.model.enums;

import model.*;
import java.util.*;

public enum NPC {
    LEAH("Leah", "Artist", Personality.ARTISTIC,
         new Location("Leah's Cabin", new Position(10,15)),
         new Schedule(Map.of(
             TimeOfDay.MORNING,   new Location("Forest",    new Position(12,16)),
             TimeOfDay.AFTERNOON, new Location("Cabin",     new Position(10,15)),
             TimeOfDay.EVENING,   new Location("Town Square",new Position(8,14))
         )),
         List.of("Salmon","Poppy","Spice Berry"),
         List.of(
            new Mission(10, "Deliver 10 Hardwood to Leah",      0,  0,
                        Map.of("Hardwood",10), 0,
                        Map.of("Coin",500),      0, 70),
            new Mission(11, "Deliver 200 Wood to Leah",         1,  0,
                        Map.of("Wood",200),     0,
                        Map.of("Recipe:Dinner Salmon",1), 0, 90),
            new Mission(12, "Bring 1 Salmon to Leah",           0, 28,
                        Map.of("Salmon",1),      0,
                        Map.of("Deluxe Scarecrow",3), 0,120)
         )
    ),

    ROBIN("Robin", "Carpenter", Personality.PRACTICAL,
         new Location("Robin's House", new Position(5,8)),
         new Schedule(Map.of(
             TimeOfDay.MORNING,   new Location("Blacksmith",    new Position(6,8)),
             TimeOfDay.AFTERNOON, new Location("Robin's Shop",  new Position(5,8)),
             TimeOfDay.EVENING,   new Location("Town Hall",      new Position(7,7))
         )),
         List.of("Stone","Wood","Coal"),
         List.of(
            new Mission(13, "Deliver 80 Wood to Robin",        0,  0,
                        Map.of("Wood",80),     0,
                        Map.of("Coin",1000),    0,65),
            new Mission(14, "Deliver 10 Iron Bars to Robin",   1,  0,
                        Map.of("Iron Bar",10),0,
                        Map.of("Bee House",3),  0,85),
            new Mission(15, "Deliver 1000 Wood to Robin",      0, 35,
                        Map.of("Wood",1000),0,
                        Map.of(),25000,        0,110)
         )
    ),

    SEBASTIAN("Sebastian", "Programmer", Personality.SHY,
         new Location("Sebastian's Lab", new Position(14,4)),
         new Schedule(Map.of(
             TimeOfDay.MORNING,   new Location("Lab",         new Position(14,4)),
             TimeOfDay.AFTERNOON, new Location("Town Square", new Position(8,14)),
             TimeOfDay.EVENING,   new Location("River Bank",   new Position(16,5))
         )),
         List.of("Frozen Tear","Iridium Bar","Obsidian"),
         List.of(
            new Mission(16, "Deliver 50 Iron to Sebastian",    0,  0,
                        Map.of("Iron",50),    0,
                        Map.of(),5000,        0,  0),
            new Mission(17, "Deliver 150 Stone to Sebastian",  1,  0,
                        Map.of("Stone",150),  0,
                        Map.of("Quartz",50),  0,  0),
            new Mission(18, "Deliver 10 Wool to Sebastian",    0, 30,
                        Map.of("Wool",10),    0,
                        Map.of("Diamond",2),  0,  0)
         )
    ),

    ABIGAIL("Abigail", "Adventurer", Personality.ADVENTUROUS,
         new Location("Abigail's House", new Position(3,3)),
         new Schedule(Map.of(
             TimeOfDay.MORNING,   new Location("Mine Entrance", new Position(2,3)),
             TimeOfDay.AFTERNOON, new Location("Town Square",   new Position(8,14)),
             TimeOfDay.EVENING,   new Location("House",         new Position(3,3))
         )),
         List.of("Pumpkin","Quartz","Amethyst"),
         List.of(
            new Mission(19, "Deliver 1 Gold Bar to Abigail",  0,  0,
                        Map.of("Gold Bar",1),0,
                        Map.of(),500,       0,  0),
            new Mission(20, "Deliver 1 Pumpkin to Abigail",   1,  0,
                        Map.of("Pumpkin",1),0,
                        Map.of("Iridium Sprinkler",1),0, 0),
            new Mission(21, "Deliver 50 Wheat to Abigail",    0, 25,
                        Map.of("Wheat",50),  0,
                        Map.of(),0,         200, 0)
         )
    ),

    HARVEY("Harvey", "Doctor", Personality.KIND,
         new Location("Harvey's Clinic", new Position(9,12)),
         new Schedule(Map.of(
             TimeOfDay.MORNING,   new Location("Clinic",       new Position(9,12)),
             TimeOfDay.AFTERNOON, new Location("Town Square",  new Position(8,14)),
             TimeOfDay.EVENING,   new Location("River Bank",    new Position(16,5))
         )),
         List.of("Coffee","Salad","Wine"),
         List.of(
            new Mission(22, "Deliver 12 Coffee to Harvey",    0,  0,
                        Map.of("Coffee",12),0,
                        Map.of(),750,       0,  0),
            new Mission(23, "Deliver 1 Salmon to Harvey",     1,  0,
                        Map.of("Salmon",1),  0,
                        Map.of(),0,         200, 0),
            new Mission(24, "Deliver 1 Wine to Harvey",       0, 20,
                        Map.of("Wine",1),    0,
                        Map.of("Salad",5),   0,  0)
         )
    );

    private final String name, job;
    private final Personality personality;
    private final Location home;
    private final Schedule schedule;
    private final List<String> favorites;
    private final Friendship friendship = new Friendship();
    private final List<Mission> missions;

    NPC(String name,
        String job,
        Personality personality,
        Location home,
        Schedule schedule,
        List<String> favorites,
        List<Mission> missions) {

        this.name = name;
        this.job = job;
        this.personality = personality;
        this.home = home;
        this.schedule = schedule;
        this.favorites = favorites;
        this.missions = missions;
    }

    public String getName() { return name; }
    public String getJob() { return job; }
    public Personality getPersonality() { return personality; }
    public Location getHome() { return home; }
    public Schedule getSchedule() { return schedule; }
    public List<String> getFavorites() { return favorites; }
    public Friendship getFriendship() { return friendship; }
    public List<Mission> getMissions() { return missions; }
}