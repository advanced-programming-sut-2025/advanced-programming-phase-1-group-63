package social;

import model.Player;
import model.Position;
import java.time.LocalDate;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

public class InteractionService {

    private static final AtomicInteger MSG_ID_GEN   = new AtomicInteger(1);
    private static final AtomicInteger GIFT_ID_GEN  = new AtomicInteger(1);
    private static final AtomicInteger TRADE_ID_GEN = new AtomicInteger(1);

    private static boolean isAdjacent(Player a, Player b) {
        Position p1 = a.getPosition();
        Position p2 = b.getPosition();
        if (p1 == null || p2 == null) return false;
        int dx = Math.abs(p1.getX() - p2.getX());
        int dy = Math.abs(p1.getY() - p2.getY());
        return dx + dy == 1;
    }

    // حرف زن
    public static void talk(Player me, Player other, String text) {
        if (!isAdjacent(me, other)) {
            System.out.println("You must be adjacent to talk.");
            return;
        }
        int mid = MSG_ID_GEN.getAndIncrement();
        Message msg = new Message(mid, me.getUsername(), other.getUsername(), text);
        me.getConversations()
          .computeIfAbsent(other.getUsername(), k -> new ArrayList<>())
          .add(msg);
        other.getConversations()
             .computeIfAbsent(me.getUsername(), k -> new ArrayList<>())
             .add(msg);

        // xp برای دو طرف
        me.getFriendshipWith(other).addXp(20);
        other.getFriendshipWith(me).addXp(20);
        System.out.printf("Message sent to %s. (+20 xp)%n", other.getUsername());
    }

    public static void talkHistory(Player me, String otherUsername) {
        List<Message> history = me.getConversations()
                                   .getOrDefault(otherUsername, Collections.emptyList());
        if (history.isEmpty()) {
            System.out.println("No conversation with " + otherUsername);
        } else {
            history.forEach(m ->
                System.out.printf("[%s → %s at %s]: %s%n",
                    m.getFromUser(), m.getToUser(),
                    m.getTimestamp(), m.getContent())
            );
        }
    }

    // هورا جایزه
    public static void gift(Player me, Player other,
                            String itemName, int amount) {
        if (me.getFriendshipWith(other).getLevel() < 1) {
            System.out.println("Friendship level ≥1 required to send gifts.");
            return;
        }
        if (!isAdjacent(me, other)) {
            System.out.println("You must be adjacent to give a gift.");
            return;
        }
        if (!me.hasItems(Map.of(itemName, amount))) {
            System.out.println("Not enough items to gift.");
            return;
        }
        me.removeItems(Map.of(itemName, amount));
        int gid = GIFT_ID_GEN.getAndIncrement();
        Gift g = new Gift(gid, me.getUsername(), other.getUsername(), itemName, amount);
        me.getGiftsSent().add(g);
        other.getGiftsReceived().add(g);
        System.out.printf("You sent %d x %s to %s. Awaiting rating...%n",
                          amount, itemName, other.getUsername());
    }

    public static void giftList(Player me) {
        List<Gift> rec = me.getGiftsReceived();
        if (rec.isEmpty()) {
            System.out.println("No gifts received.");
            return;
        }
        rec.forEach(g ->
            System.out.printf("[%d] From: %s, Item: %s x%d at %s, Rated: %s%n",
                g.getId(), g.getFromUser(), g.getItemName(),
                g.getAmount(), g.getSentAt(),
                g.isRated() ? ("yes (" + g.getRating() + ")") : "no")
        );
    }

    public static void giftRate(Player me, int giftId, int rate) {
        Optional<Gift> opt = me.getGiftsReceived()
                                .stream()
                                .filter(g -> g.getId() == giftId)
                                .findFirst();
        if (opt.isEmpty()) {
            System.out.println("Invalid gift ID.");
            return;
        }
        Gift g = opt.get();
        if (g.isRated()) {
            System.out.println("Gift already rated.");
            return;
        }
        g.rate(rate);
        int deltaXp = 15 + 30 * (3 - rate);

        // نوتیف و xp برای هر دو طرف
        Player sender = me.getServer().findPlayer(g.getFromUser());
        me.getFriendshipWith(sender).addXp(deltaXp);
        sender.getFriendshipWith(me).addXp(deltaXp);
        System.out.printf("Gift rated %d. Friendship xp %+d for both.%n",
                          rate, deltaXp);
    }

    public static void giftHistory(Player me, String otherUsername) {
        List<Gift> all = new ArrayList<>();
        all.addAll(me.getGiftsSent());
        all.addAll(me.getGiftsReceived());
        all.stream()
           .filter(g -> g.getFromUser().equals(otherUsername)
                     || g.getToUser().equals(otherUsername))
           .forEach(g ->
                System.out.printf("[%d] %s → %s : %s x%d at %s, rated: %s%n",
                    g.getId(),
                    g.getFromUser(), g.getToUser(),
                    g.getItemName(), g.getAmount(),
                    g.getSentAt(),
                    g.isRated() ? g.getRating() : "no")
           );
    }

    // سلام دوستم!
    public static void hug(Player me, Player other) {
        if (me.getFriendshipWith(other).getLevel() < 2) {
            System.out.println("Friendship level ≥2 required to hug.");
            return;
        }
        if (!isAdjacent(me, other)) {
            System.out.println("You must be adjacent to hug.");
            return;
        }
        me.getFriendshipWith(other).addXp(60);
        other.getFriendshipWith(me).addXp(60);
        System.out.println("Hugged! (+60 xp)");
    }

    public static void flower(Player me, Player other) {
        if (me.getFriendshipWith(other).getLevel() < 2) {
            System.out.println("Friendship level ≥2 required to give a flower.");
            return;
        }
        if (!isAdjacent(me, other)) {
            System.out.println("You must be adjacent to give a flower.");
            return;
        }
        if (!me.hasItem("Bouquet", 1)) {
            System.out.println("You don't have a Bouquet.");
            return;
        }
        me.removeItem("Bouquet", 1);
        int needXp = me.getFriendshipWith(other).xpForNextLevel();
        me.getFriendshipWith(other).addXp(needXp);
        other.getFriendshipWith(me).addXp(needXp);
        System.out.println("You gave a flower! Both reached level 3.");
    }

    //یه خواستگاریمون بشه؟
    public static void askMarriage(Player me, Player other, String ringItem) {
        if (me.getFriendshipWith(other).getLevel() < 3) {
            System.out.println("Friendship level must be 3 to propose.");
            return;
        }
        if (!isAdjacent(me, other)) {
            System.out.println("You must be adjacent to propose.");
            return;
        }
        if (me.isMarried() || other.isMarried()) {
            System.out.println("One of you is already married.");
            return;
        }
        if (!me.hasItem(ringItem, 1)) {
            System.out.println("You don't have the ring.");
            return;
        }
        if (me.getGender().equals(other.getGender())) {
            System.out.println("Marriage requires opposite gender.");
            return;
        }

        // دست و جیغ و هورا
        me.removeItem(ringItem, 1);
        me.setMarried(true);
        other.setMarried(true);
        me.setSpouseUsername(other.getUsername());
        other.setSpouseUsername(me.getUsername());
        // دستمون رفت تو جیب هم
        int tot = me.getBalance() + other.getBalance();
        me.setBalance(tot);
        other.setBalance(tot);
        System.out.printf("Congratulations! %s and %s are now married.%n",
                          me.getUsername(), other.getUsername());
    }

    // دلالی
    public static void proposeTrade(Player me, Player other,
                                    Map<String,Integer> offer,
                                    Map<String,Integer> request) {
        if (!isAdjacent(me, other)) {
            System.out.println("You must be adjacent to trade.");
            return;
        }
        int tid = TRADE_ID_GEN.getAndIncrement();
        TradeOffer to = new TradeOffer(tid, me.getUsername(),
                                       other.getUsername(),
                                       new HashMap<>(offer),
                                       new HashMap<>(request));
        me.getOutgoingTrades().put(tid, to);
        other.getIncomingTrades().put(tid, to);
        System.out.printf("Trade offer #%d sent to %s%n",
                          tid, other.getUsername());
    }

    public static void acceptTrade(Player me, int tradeId) {
        TradeOffer offer = me.getIncomingTrades().get(tradeId);
        if (offer == null) {
            System.out.println("No such incoming trade.");
            return;
        }
        Player sender = me.getServer().findPlayer(offer.getFromUser());
        if (!isAdjacent(me, sender)) {
            System.out.println("You must be adjacent to accept trade.");
            return;
        }

        // پول داری اصن؟
        if (!sender.hasItems(offer.getOfferItems())
         || !me.hasItems(offer.getRequestItems())) {
            System.out.println("One side does not have required items.");
            return;
        }

        // بده بزنیم
        sender.removeItems(offer.getOfferItems());
        me.addItems(offer.getOfferItems());
        me.removeItems(offer.getRequestItems());
        sender.addItems(offer.getRequestItems());

        // غلط کردم
        sender.getOutgoingTrades().remove(tradeId);
        me.getIncomingTrades().remove(tradeId);
        System.out.printf("Trade #%d accepted between %s and %s.%n",
                          tradeId, sender.getUsername(), me.getUsername());
    }

    public static void cancelTrade(Player me, int tradeId) {
        // شاید توبه
        TradeOffer out = me.getOutgoingTrades().remove(tradeId);
        TradeOffer in  = me.getIncomingTrades().remove(tradeId);
        if (out == null && in == null) {
            System.out.println("No such trade to cancel.");
            return;
        }
        if (out != null) {
            Player other = me.getServer().findPlayer(out.getToUser());
            other.getIncomingTrades().remove(tradeId);
        }
        if (in != null) {
            Player other = me.getServer().findPlayer(in.getFromUser());
            other.getOutgoingTrades().remove(tradeId);
        }
        System.out.printf("Trade #%d cancelled.%n", tradeId);
    }
}
