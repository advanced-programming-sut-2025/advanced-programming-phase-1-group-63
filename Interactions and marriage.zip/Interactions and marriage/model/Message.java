package social;

import java.time.LocalDateTime;

public class Message {
    private final int id;
    private final String fromUser;
    private final String toUser;
    private final String content;
    private final LocalDateTime timestamp;

    public Message(int id, String from, String to, String content) {
        this.id = id;
        this.fromUser = from;
        this.toUser = to;
        this.content = content;
        this.timestamp = LocalDateTime.now();
    }

    public int getId() { return id; }
    public String getFromUser() { return fromUser; }
    public String getToUser() { return toUser; }
    public String getContent() { return content; }
    public LocalDateTime getTimestamp() { return timestamp; }
}
