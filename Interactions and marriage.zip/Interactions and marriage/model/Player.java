package model;

import social.*;
import java.time.LocalDate;
import java.util.*;

public class Player extends User {

    private Position position;
    //تو جیبت چقدره؟
    private int balance = 0;

    // خدایا قسمت ما هم بشه
    private boolean married = false;
    private String spouseUsername = null;

    //طلاق!
    private LocalDate marriagePenaltyUntil = null;

    //ای شیطون بلا
    private final Set<LocalDate> spouseBonusDates = new HashSet<>();

    //دوستیامون
    private final Map<String, Friendship> friendships = new HashMap<>();
    //هر چقدر زر میزنی
    private final Map<String, List<Message>> conversations = new HashMap<>();
    //جایزه بگیر
    private final List<Gift> giftsReceived = new ArrayList<>();
    //جایزه بده
    private final List<Gift> giftsSent = new ArrayList<>();
    //پیشنهاد جایزه
    private final Map<Integer, TradeOffer> incomingTrades = new HashMap<>();
    //دلالی
    private final Map<Integer, TradeOffer> outgoingTrades = new HashMap<>();

    //یه اینونتوری ساده(جای کار داره)
    private final Map<String,Integer> inventory = new HashMap<>();

    public Player(User base) {
        super(base.getUsername(),
              base.getPassword(),
              base.getNickname(),
              base.getEmail(),
              base.getGender());
    }

    public Position getPosition() {
        return position;
    }
    public void setPosition(Position position) {
        this.position = position;
    }

    public int getBalance() {
        return balance;
    }
    public void setBalance(int balance) {
        this.balance = balance;
    }
    public void addBalance(int delta) {
        this.balance += delta;
    }

    public boolean isMarried() {
        return married;
    }
    public void setMarried(boolean married) {
        this.married = married;
    }
    public String getSpouseUsername() {
        return spouseUsername;
    }
    public void setSpouseUsername(String spouseUsername) {
        this.spouseUsername = spouseUsername;
    }
    public LocalDate getMarriagePenaltyUntil() {
        return marriagePenaltyUntil;
    }
    public void setMarriagePenaltyUntil(LocalDate until) {
        this.marriagePenaltyUntil = until;
    }
    //رفتی پیش زنت؟
    public boolean hasReceivedSpouseBonusToday() {
        return spouseBonusDates.contains(LocalDate.now());
    }
    //خیلی قشنگ شد
    public void markSpouseBonusReceivedToday() {
        spouseBonusDates.add(LocalDate.now());
    }

    public Friendship getFriendshipWith(Player other) {
        return friendships
            .computeIfAbsent(other.getUsername(), k -> new Friendship());
    }
    //همه رفیقای ارزالت
    public Map<String, Friendship> getAllFriendships() {
        return Collections.unmodifiableMap(friendships);
    }

    public Map<String, List<Message>> getConversations() {
        return conversations;
    }

    public List<Gift> getGiftsReceived() {
        return giftsReceived;
    }
    public List<Gift> getGiftsSent() {
        return giftsSent;
    }

    public Map<Integer, TradeOffer> getIncomingTrades() {
        return incomingTrades;
    }
    public Map<Integer, TradeOffer> getOutgoingTrades() {
        return outgoingTrades;
    }

    //یه ایتم برمیگردونه
    public int getItemCount(String itemName) {
        return inventory.getOrDefault(itemName, 0);
    }
    public boolean hasItem(String itemName, int count) {
        return getItemCount(itemName) >= count;
    }
    public void addItem(String itemName, int count) {
        if (count <= 0) return;
        inventory.put(itemName, getItemCount(itemName) + count);
    }
    public void removeItem(String itemName, int count) {
        int cur = getItemCount(itemName);
        if (count <= 0 || cur < count) return;
        inventory.put(itemName, cur - count);
    }
    //بررسی گروهی ایتم ها
    public boolean hasItems(Map<String, Integer> items) {
        return items.entrySet().stream()
            .allMatch(e -> hasItem(e.getKey(), e.getValue()));
    }
    //حذفشون حالا
    public void removeItems(Map<String, Integer> items) {
        items.forEach(this::removeItem);
    }
    //اضاف
    public void addItems(Map<String, Integer> items) {
        items.forEach(this::addItem);
    }

    //اینو باید هر روز تو سرور فراخوانی کنیم چون روز به روزه دیگه
    public void nextDay() {

        friendships.values().forEach(Friendship::dailyDecay);
    }

    public GameServer getServer() {
        // TODO: اینجا اجتمالا تو فاز 3 و بحث سرور و شبکه بدرد بخوره
        return null;
    }
}
