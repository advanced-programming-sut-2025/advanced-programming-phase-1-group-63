package social;

import java.time.LocalDateTime;
import java.util.Map;

//مدل دلالی حرفه ای

public class TradeOffer {
    public enum Status { PENDING, ACCEPTED, REJECTED, EXPIRED }

    private final int id;
    private final String fromUser;
    private final String toUser;
    private final Map<String,Integer> offeredItems;
    private final Map<String,Integer> requestedItems;
    private Status status = Status.PENDING;
    private final LocalDateTime createdAt;

    public TradeOffer(int id,
                      String fromUser,
                      String toUser,
                      Map<String,Integer> offeredItems,
                      Map<String,Integer> requestedItems) {
        this.id = id;
        this.fromUser = fromUser;
        this.toUser = toUser;
        this.offeredItems = offeredItems;
        this.requestedItems = requestedItems;
        this.createdAt = LocalDateTime.now();
    }

    public int getId() { return id; }
    public String getFromUser() { return fromUser; }
    public String getToUser() { return toUser; }
    public Map<String,Integer> getOfferedItems() { return offeredItems; }
    public Map<String,Integer> getRequestedItems() { return requestedItems; }
    public Status getStatus() { return status; }
    public void setStatus(Status s) { this.status = s; }
    public LocalDateTime getCreatedAt() { return createdAt; }
}