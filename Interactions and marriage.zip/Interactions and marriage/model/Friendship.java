package social;

import java.time.LocalDate;


public class Friendship {
    private int xp = 0;
    private int level = 0;
    private LocalDate lastInteractionDate = null;
    private boolean interactedToday = false;


    public void addXp(int amount) {
        LocalDate today = LocalDate.now();
        if (!today.equals(lastInteractionDate)) {
            interactedToday = false;
        }
        if (!interactedToday) {
            xp += amount;

            while (xp >= xpForNextLevel()) {
                xp -= xpForNextLevel();
                level++;
            }
            interactedToday = true;
        }
        lastInteractionDate = today;
    }

    //ببینیم روزانه جه خبره
    public void dailyDecay() {
        LocalDate today = LocalDate.now();
        if (lastInteractionDate == null || !today.equals(lastInteractionDate)) {

            // زرشک
            if (xp > 0) {
                xp = Math.max(0, xp - 10);
            } else if (level > 0) {
                level--;
                xp = xpForNextLevel() - 10;
            }
        }

        // فلگ تعامل امروز را برای روز بعد ریست کن
        if (today.isAfter(lastInteractionDate)) {
            interactedToday = false;
        }
    }

    //جقدر ایکس پی کیخوای
    public int xpForNextLevel() {
        return 100 * (1 + level);
    }

    public int getXp() { return xp; }
    public int getLevel() { return level; }
}
