package social;

import java.time.LocalDateTime;

public class Gift {
    private final int id;
    private final String fromUser;
    private final String toUser;
    private final String itemName;
    private final int amount;
    private final LocalDateTime sentAt;
    private boolean rated = false;
    private int rating;  // 1..5

    public Gift(int id, String from, String to, String itemName, int amount) {
        this.id = id;
        this.fromUser = from;
        this.toUser = to;
        this.itemName = itemName;
        this.amount = amount;
        this.sentAt = LocalDateTime.now();
    }

    public int getId() { return id; }
    public String getFromUser() { return fromUser; }
    public String getToUser() { return toUser; }
    public String getItemName() { return itemName; }
    public int getAmount() { return amount; }
    public LocalDateTime getSentAt() { return sentAt; }
    public boolean isRated() { return rated; }
    public int getRating() { return rating; }

    //از خدمات خود چقدر راضی بودین!
    public void rate(int rate) {
        if (rate < 1 || rate > 5) {
            throw new IllegalArgumentException("Rating must be 1..5");
        }
        this.rating = rate;
        this.rated = true;
    }
}
